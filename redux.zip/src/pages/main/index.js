import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Box } from "@mui/material";

export const Main = () => {

  const navigate = useNavigate();
  const dispath = useDispatch();
  const store = useSelector(state => state);

  const [page, setPage] = useState(1);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [usernameR, setUsernameR] = useState("");
  const [password1, setPassword1] = useState("");
  const [password2, setPassword2] = useState("");


  const checkUser = () => {
    return store.users.users.find(v => v.name === usernameR);
  }

  const findUser = () => {
    return store.users.users.find(v => v.name === username && v.password === password);
  }

  const logIn = () => {
    let user = findUser();
    if (user) {
      dispath(({ type: "newuser", id: user.id, name: user.name, password: user.password }));
      navigate("/profile");
    } else {
      alert("Неверный логин или пароль!");
    }
  }

  const register = () => {
    if (password1 == password2) {
      let userExist = checkUser();
      if (!userExist) {
        dispath(({ type: "addnew", name: usernameR, password: password1 }));
        alert("Пользователь создан!");
        setUsernameR("");
        setPassword1("");
        setPassword2("");
      } else {
        alert("Нельзя регистрировать пользователей с одинаковыми именами!");
      }
    } else {
      alert("Пароли разные!");
    }
  }

  return (
    <Box display="flex" alignItems="center" justifyContent="center" height="100vh">
      {page === 1 ?
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          minWidth="400px"
          padding="30px"
          border="2px solid #FFF"
          gap="10px"
        >
          <h2 style={{ color: "#FFF" }}>Войдите в аккаунт!</h2>
          <input className="input" placeholder="Логин" value={username} onChange={(e) => setUsername(e.target.value)} />
          <input className="input" type="password" placeholder="Пароль" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button className="button" onClick={logIn} disabled={!username || !password}>ВОЙТИ</button>
          <span className="link" onClick={() => setPage(2)}>Зарегистрироваться!</span>
        </Box> :
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          minWidth="400px"
          padding="30px"
          border="2px solid #FFF"
          gap="10px"
        >
          <h2 style={{ color: "#FFF" }}>Зарегистрируйте аккаунт!</h2>
          <input className="input" placeholder="Логин" value={usernameR} onChange={(e) => setUsernameR(e.target.value)} />
          <input className="input" type="password" placeholder="Пароль" value={password1} onChange={(e) => setPassword1(e.target.value)} />
          <input className="input" type="password" placeholder="Повторите пароль" value={password2} onChange={(e) => setPassword2(e.target.value)} />
          <button className="button" onClick={register} disabled={!usernameR || !password1 || !password2}>ЗАРЕГИСТРИРОВАТЬСЯ</button>
          <span className="link" onClick={() => setPage(1)}>Войти!</span>
        </Box>
      }
    </Box>
  );
}