import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Box } from "@mui/material";

export const Profile = () => {

  const navigate = useNavigate();

  const dispath = useDispatch();

  const store = useSelector(state => state);

  const [currentUser, setCurrentUser] = useState(false);

  const exit = () => {
    dispath(({ type: "del" }));
    navigate("/");
  }

  useEffect(() => {

    const getCurrrentUser = () => {
      if (store.user.user.name != null) {
        setCurrentUser(store.user.user);
      } else {
        navigate("/");
      }
    }

    getCurrrentUser();
  }, []);

  return (
    <Box display="flex" alignItems="center" justifyContent="center" height="100vh">
      {currentUser &&
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          minWidth="200px"
          padding="30px"
          border="2px solid #FFF"
          gap="20px"
        >
          <Box width='100%' display="flex" justifyContent="space-between">
            <span style={{ fontSize: "20px", color: "white" }}>Имя: <b>{currentUser.name}</b></span>
            <span style={{ fontSize: "20px", color: "white" }}>ID: <b>{currentUser.id}</b></span>
          </Box>
          <button className="button" onClick={exit}>Выйти</button>
        </Box>}
    </Box>
  );
}