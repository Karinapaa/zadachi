
import { Route, Routes } from "react-router-dom";
import { Main } from "./pages/main";
import { Profile } from "./pages/profile";
import './App.css'

const App = () => (
  <>
    <Routes>
      <Route element={<Main />} path='/' />
      <Route element={<Profile />} path='/profile'/>
    </Routes>
  </>

)

export default App;