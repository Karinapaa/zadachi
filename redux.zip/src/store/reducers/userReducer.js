const initState = {
    user: {id: null, name: null, password: null}
}

export const userReducer = (state = initState, action) => {
    if (action.type === "newuser") {
        return {...state, user: {id: action.id, name: action.name, password: action.password}}
    } else if (action.type === "del") {
        return {...state, user: {id: null, name: null, password: null}}
    } else {
        return {...state}
    }
}